<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package _tk
 */
?>
			</div><!-- close .*-inner (main-content or sidebar, depending if sidebar is used) -->
		</div><!-- close .row -->
	</div><!-- close .container -->
</div><!-- close .main-content -->

<footer id="colophon" class="site-footer" role="contentinfo">
<?php // substitute the class "container-fluid" below if you want a wider content area ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
					<div class="menu-footer">Menu</div>
					<div class="menu-footer">Menu</div>
					<div class="menu-footer">Menu</div>
					<div class="menu-footer">Menu</div>
					<div class="menu-footer">Menu</div>
					<div class="menu-footer">Menu</div>
			</div>
			<div class="col-md-4 ">
				<div class="follow-footer aligncenter">Follow Us</div>
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-instagram"></i></a></li>
					<a href="#"><i class="fa fa-google-plus"></i></a>
			</div>
			<div class="col-md-4">
				<p class="contact-footer alignright">Contact Us</p>
		</div>
	</div><!-- close .container -->
</footer><!-- close #colophon -->

<?php wp_footer(); ?>

</body>
</html>
